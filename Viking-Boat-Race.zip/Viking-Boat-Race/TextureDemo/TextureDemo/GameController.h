#pragma once
class GameController
{
public:
	GameController();
	~GameController();
};

